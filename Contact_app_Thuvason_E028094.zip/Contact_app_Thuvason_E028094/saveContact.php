<?php

//storing the retrived values in variables 
if(isset($_FILES['my_image'])){	
	$img_name = $_FILES['my_image']['name'];
    $img_size = $_FILES['my_image']['size'];
    $tmp_name = $_FILES['my_image']['tmp_name'];
    $error = $_FILES['my_image']['error'];

	//running the condition if there are no errors
    if ($error === 0){
		//checking wheher the file is less than 10mb
        if ($img_size > 1250000){
            $em = "Sorry, the file is too large!";
            header("Location: saveBook.php?error=$em");
        }else {
			//geting the extension of the file
            $img_ex = pathinfo($img_name, PATHINFO_EXTENSION);
            $img_ex_lc = strtolower($img_ex);
			//extensions of allowed file types
            $allowed_exs = array("jpg", "jpeg", "png");
			//checking whether the recived file is an image using the extension
            if (in_array($img_ex_lc, $allowed_exs)){
				//saving the new image name
                $new_img_name = uniqid("IMG-", true).'.'.$img_ex_lc;
				//uploading the image with the new name in the upload folder
                $img_upload_path = 'uploads/'.$new_img_name;
                move_uploaded_file($tmp_name, $img_upload_path);

                

            }else{
                $em = "Can't upload this file type!";
                header("Location: saveBook.php?error=$em");
            }	
	}}}

if(isset($_POST['contact_name'])){	
$contact_name=$_POST['contact_name'];	
}


if(isset($_POST['email'])){	
$email=$_POST['email'];	
}

if(isset($_POST['contact'])){	
$contact=$_POST['contact'];	
}

//include database connection	
include('inc/dbConn.php');

//sql query
 $sql="INSERT INTO `contact` (`image`, `contact_name`, `contact`, `email`) 
 VALUES ('$new_img_name', '$contact_name', '$contact', '$email');"	;

//stroing the result
	$result=mysqli_query($conn,$sql);



//display the message according to the result	
	if($result){

		?>

		<script>
				alert("Data added successfully");
				window.location="index.php";
        </script>
		
	<?php		
	}else{
	
		?>

		<script>
				alert("Something went wrong");
				window.location="index.php";
        </script>
		
	<?php	
	}
	
	
	
	

//close database connection
mysqli_close($conn);
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	











?>