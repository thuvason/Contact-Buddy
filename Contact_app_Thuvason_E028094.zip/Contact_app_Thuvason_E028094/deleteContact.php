<?php

//check the userID and saving it
if(isset($_GET['userID'])){	
$userID=$_GET['userID'];	
}



	
//database connection	
include('inc/dbConn.php');

//query
 $sql="DELETE FROM contact WHERE userID = $userID"	;

//storing the results in variable
	$result=mysqli_query($conn,$sql);



//display message according to results	
	if($result){
	

	
	header('location:index.php');	
		
		
	}else{
		?>

		<script>
				alert("Something went wrong");
				window.location="index.php";
        </script>
		
	<?php	
	}
	
	
	
	
	
//close connection
mysqli_close($conn);
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	











?>