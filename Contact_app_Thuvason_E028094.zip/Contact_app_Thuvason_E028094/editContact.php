<?php include('inc/head.php');?>


  <body >
	 <?php
	  
	  if(isset($_GET['userID'])){
		  $userID=$_GET['userID'];
	  } 
	  ?> 
	
	  
	  
	  
	  <section class="container-fluid" style=";margin-top: 50px">
	  
		  
		  
		  
		  
		  
    <h1 class="jumbotron" align = "center">Edit Contact</h1>
	  </section>
	  
	  
	<section class="container table-responsive" style="min-height: 400px;"> 
	<?php 
	  include('inc/dbConn.php'); 
	  
	  
 $sql="SELECT  * from contact where userID=$userID limit 1 "	;


	$result=mysqli_query($conn,$sql);
	
	$no=mysqli_num_rows($result);
	
	if($no>0){
		
		
		?>
		
		<form action="updateContact.php" id="myForm" method="post">
	  <table class="table table-bordered table-hover " >
		  
		 
		  
		 
	  
	  <?php
		$no=0;
	while( $row=mysqli_fetch_assoc($result))	{
		$no++;
		?>
		
		  
		<tr>
			<td>Name</td>
		  <td> <input name="userID" type="hidden" value="<?php echo $row['userID']; ?>"  />
			  <input name="contact_name" type="text" value="<?php echo $row['contact_name']; ?>"  class="form-control"/></td>
		  </tr>	
			
			<tr>
			<td>Contact</td>	
		  <td><input name="contact" type="text" value="<?php echo $row['contact']; ?>" class="form-control"/></td>
		  </tr>	
			<tr>
			 <td>Email</td>	
			<td><input name="email" type="email" value="<?php echo $row['email']; ?>" class="form-control"/></td>
		  </tr>	
	<?php	
	}
	 
	?>
		  
	</table>	
		</form>	
	<?php  
	}
	  
	 
	  ?>
	 
		
		<button form="myForm" type="submit" class="btn btn-primary pull-right" data-toggle="modal" data-target="#saveContactModal"> <span class="glyphicon glyphicon-plus"></span> Update</button>
		
		
</section>  	  
	  
	  
	  
	  
	  
	  
 <?php include('inc/footer.php'); ?>	 

 <?php include('inc/scripts.php'); ?>	
	  
<?php include('inc/allModals.php'); ?>

	<script>
	  function getConfirmation(){
		  var x=confirm("is this ok?");
		  
		  if(x==true){
			  return true;
		  }else{
			return false;  
		  }
		  
		  
	  }
	  
	  
	  </script>  
	  
	  
	  
	  
	
	  
	  
	  
  </body>


</html>