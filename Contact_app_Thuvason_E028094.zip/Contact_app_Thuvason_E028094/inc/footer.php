<section class="container-fluid "  >
	  <div class="row myFooter" style="background-color: orange;color:#ffa">
			<div class="col-sm-4 ">Contact Buddy</div>
		   <div class="col-sm-4 ">Developed by Thuvason Sarvananthan</div>
		   <div class="col-sm-4 ">E028094</div>
		</div>
	  
	</section> 


