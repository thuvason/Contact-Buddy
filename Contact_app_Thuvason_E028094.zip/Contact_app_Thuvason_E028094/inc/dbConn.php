<?php

$conn=mysqli_connect("localhost","id20011257_thuvason","^YcMO6Pe@@evGO<?","id20011257_contact");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }


?>