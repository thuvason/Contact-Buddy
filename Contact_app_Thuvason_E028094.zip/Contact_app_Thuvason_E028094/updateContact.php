<?php

//storing the retrived values in variables 
if(isset($_POST['userID'])){	
$userID=$_POST['userID'];	
}

if(isset($_POST['contact_name'])){	
$contact_name=$_POST['contact_name'];	
}

if(isset($_POST['contact'])){	
$contact=$_POST['contact'];	
}

if(isset($_POST['email'])){	
$email=$_POST['email'];	
}
	
//creating the database connection	
include('inc/dbConn.php');

//sql query
 $sql="update contact set userID='$userID' , contact_name='$contact_name', email='$email' WHERE userID='$userID'"	;

//stroing the result in variable
	$result=mysqli_query($conn,$sql);



//alert message to the user which indicate whether action is succseful or unsuccessful	
	if($result){
	?>
	<script>
				alert("Successfully Updated");
				window.location="index.php";
        </script>
	
	
	<?php	
		
	}else{
		?>

		<script>
				alert("Something went wrong");
				window.location="index.php";
        </script>
		
	<?php	
	}
	
	
	
	
	
//close database connection
mysqli_close($conn);
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	











?>