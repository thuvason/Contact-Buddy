<?php include('inc/head.php'); //include head part?>


  <body > 
	  <section class="container-fluid" style=";margin-top: 50px">
    <h1 class="jumbotron" align="center" style = "background-color: orange; color: #ffa">Contact Buddy</h1>
	  </section>
	  
	  
	<section class="container table-responsive" style="min-height: 400px;"> 
		
		<form class="navbar-form pull-right " action="index.php">
		<div class="form-group">
		<input type="text" class="form-control" placeholder="Search by name" name="sk">
		</div>
		<button type="submit" class="btn btn-primary" style = "background-color: orange; color: #ffa" >Search</button>
		</form>	
		<a href="index.php" class="btn btn-success" style = "background-color: orange; color: #ffa" >ALL</a>
	</div>	
		
	<?php 
	  include('inc/dbConn.php'); 
	  
	  
		$sql="SELECT  * from contact";
			
		if(isset($_GET['sk'])){
			$sk=$_GET['sk'];
		$sql="SELECT * FROM `contact` WHERE contact_name LIKE '%$sk%';"	;	
			
		}		
			


	$result=mysqli_query($conn,$sql);
	
	$no=mysqli_num_rows($result);
	
	if($no>0){
		
		
		?>
	  <table class="table table-bordered table-responsive">
        <thead>
		  <tr style="background-color: #000;color:#fff">
			  <th scope="col" >Image</th>
			  <th scope="col" >Name</th>
			  <th scope="col" >Number</th>
			  <th scope="col" >Email</th>
              <th scope="col" colspan="2" align="center">Action</th>
		  </tr>
        </thead>
	  <?php
		$no=0;
	while( $row=mysqli_fetch_assoc($result))	{
		$no++;
		$image = $row['image'];
		$image_path = 'uploads/'.$image;
		?>
        <tbody>
		<tr>
			<td><?php echo "<img class ='image' src='$image_path'/>";?></td>
			<td><?php echo $row['contact_name']; ?></td>
			<td><?php echo $row['contact']; ?></td>
			<td><?php echo $row['email']; ?></td>
			
<td> 
				<form action="editContact.php">
					<input type="hidden" name="userID" value="<?php echo $row['userID']; ?>">
				<button type="submit" class="btn btn-primary btn-sm">
				<span class="glyphicon glyphicon-pencil"></span>
				</button>
				</form>	
					</td>
			<td>
				<form action="deleteContact.php" onSubmit=" return getConfirmation();">
					<input type="hidden" name="userID" value="<?php echo $row['userID']; ?>">
				<button type="submit" class="btn btn-danger btn-sm">
				<span class="glyphicon glyphicon-trash"></span>
				</button>
					</form>
					
					</td>
			
    </tbody>
	 
	
    <?php	
	}
	 
	?>
		  
	</table>	
		
	<?php  
	}
	  
	 
	  ?>
	 
		<button class="btn btn-primary" data-toggle="modal" data-target="#saveContactModal">
         <span class="glyphicon glyphicon-plus"></span> Add New Contact</button>
</section>  	  
	  
	  
	  
	  
	  
	  
 <?php include('inc/footer.php'); ?>	 

 <?php include('inc/scripts.php'); ?>	
	  
<?php include('inc/allModals.php'); ?>

	<script>
	  function getConfirmation(){
		  var x=confirm("is this ok?");
		  
		  if(x==true){
			  return true;
		  }else{
			return false;  
		  }
		  
		  
	  }
	  
	  
	  </script>  
	  
	  
	  
	  
	<!-- add new book modal-->

<div class="modal fade" id="saveContactModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="exampleModalLabel"> <span class="glyphicon glyphicon-plus"></span> Add New Contact</h4>
      </div>
		<form action="saveContact.php" method="post" enctype="multipart/form-data">
		
      <div class="modal-body">

	  <div class="form-group">
            <label for="image" class="control-label">Image</label>
            <input type="file" class="form-control" id="title" name="my_image" required>
          </div>
        
          <div class="form-group">
            <label for="contact_name" class="control-label">Name</label>
            <input type="text" class="form-control" id="contact_name" name="contact_name" required>
          </div>
		  
		   <div class="form-group">
            <label for="contact" class="control-label">Contact</label>
            <input type="text" class="form-control" id="contact" name="contact" required>
          </div>

          <div class="form-group">
            <label for="email" class="control-label">Email</label>
            <input type="email" class="form-control" id="email" name="email" required>
          </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Save</button>
      </div>
	</form>		
			
    </div>
  </div>
</div>

<!-- end  modal-->  
	  
	  
	  
  </body>


</html>